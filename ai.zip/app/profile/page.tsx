import { ProfilePage } from '@/components/profile/profile-page'

export const metadata = {
  title: '个人中心 - AI应用广场',
  description: '查看我的作品、消费记录和支付记录',
}

export default function ProfileRoute() {
  return <ProfilePage />
}
