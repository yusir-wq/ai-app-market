'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import type { ChatHistory } from '@/lib/mock-data'
import { cn } from '@/lib/utils'
import { Pencil, Trash2 } from 'lucide-react'

interface ChatHistoryItemProps {
  history: ChatHistory
  isSelected: boolean
  onClick: () => void
}

function formatTime(date: Date): string {
  const now = new Date()
  const diff = now.getTime() - date.getTime()
  const days = Math.floor(diff / (1000 * 60 * 60 * 24))
  
  if (days === 0) {
    return date.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })
  } else if (days === 1) {
    return '昨天'
  } else if (days < 7) {
    return `${days}天前`
  } else {
    return date.toLocaleDateString('zh-CN', { month: 'short', day: 'numeric' })
  }
}

export function ChatHistoryItem({ history, isSelected, onClick }: ChatHistoryItemProps) {
  const [isHovered, setIsHovered] = useState(false)

  return (
    <div
      onClick={onClick}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      className={cn(
        'px-3 py-2 rounded-lg cursor-pointer transition-colors group',
        'hover:bg-accent',
        isSelected && 'bg-accent'
      )}
    >
      <div className="flex items-center justify-between gap-2">
        <div className="flex-1 min-w-0">
          <p className="text-sm text-foreground truncate">{history.title}</p>
          <p className="text-xs text-muted-foreground mt-0.5">
            {formatTime(history.createdAt)}
          </p>
        </div>
        {isHovered && (
          <div className="flex items-center gap-0.5 shrink-0">
            <Button
              variant="ghost"
              size="icon-sm"
              className="h-6 w-6"
              onClick={(e) => {
                e.stopPropagation()
                // 重命名逻辑占位
              }}
            >
              <Pencil className="h-3 w-3" />
            </Button>
            <Button
              variant="ghost"
              size="icon-sm"
              className="h-6 w-6 text-destructive hover:text-destructive"
              onClick={(e) => {
                e.stopPropagation()
                // 删除逻辑占位
              }}
            >
              <Trash2 className="h-3 w-3" />
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}
