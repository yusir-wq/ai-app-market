'use client'

import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import Link from 'next/link'
import { LogOut } from 'lucide-react'
import { useAuth } from '@/contexts/auth-context'

export function Header() {
  const { isLoggedIn, user, setShowLoginModal, setShowRechargeModal, logout } = useAuth()

  return (
    <header className="h-[60px] border-b border-border bg-background px-4 flex items-center justify-between fixed top-0 left-0 right-0 z-50">
      {/* 左侧 Logo 和名称 */}
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 rounded-lg bg-foreground flex items-center justify-center">
          <span className="text-background font-bold text-sm">AI</span>
        </div>
        <span className="font-semibold text-foreground">AI应用广场</span>
      </div>

      {/* 右侧用户信息 */}
      <div className="flex items-center gap-4">
        {isLoggedIn && user ? (
          <>
            <div className="flex items-center gap-2 text-sm">
              <span className="text-muted-foreground">剩余额度:</span>
              <span className="font-medium text-foreground">¥{user.balance.toFixed(2)}</span>
            </div>
            <Button size="sm" variant="outline" onClick={() => setShowRechargeModal(true)}>
              充值
            </Button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <div className="flex items-center gap-2 cursor-pointer hover:opacity-75 transition-opacity">
                  <Avatar className="w-8 h-8">
                    <AvatarImage src={user.avatar} />
                    <AvatarFallback>U</AvatarFallback>
                  </Avatar>
                  <span className="text-sm text-foreground">{user.id}</span>
                </div>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <div className="px-2 py-1.5">
                  <p className="text-xs text-muted-foreground">用户ID</p>
                  <p className="text-sm font-medium text-foreground">{user.id}</p>
                </div>
                <div className="px-2 py-1.5">
                  <p className="text-xs text-muted-foreground">剩余额度</p>
                  <p className="text-sm font-medium text-foreground">¥{user.balance.toFixed(2)}</p>
                </div>
                <DropdownMenuSeparator />
                <Link href="/profile?tab=works">
                  <DropdownMenuItem>我的作品</DropdownMenuItem>
                </Link>
                <Link href="/profile?tab=consumption">
                  <DropdownMenuItem>消费记录</DropdownMenuItem>
                </Link>
                <Link href="/profile?tab=payment">
                  <DropdownMenuItem>支付记录</DropdownMenuItem>
                </Link>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  className="text-destructive gap-2 cursor-pointer"
                  onClick={logout}
                >
                  <LogOut className="h-4 w-4" />
                  退出登录
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </>
        ) : (
          <Button onClick={() => setShowLoginModal(true)}>
            登录
          </Button>
        )}
      </div>
    </header>
  )
}
