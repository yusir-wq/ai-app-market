'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { ScrollArea } from '@/components/ui/scroll-area'
import { History, X, MoreVertical } from 'lucide-react'
import { mockChatHistories, type Model } from '@/lib/mock-data'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'

interface HistoryDrawerProps {
  model: Model | null
  isOpen: boolean
  onClose: () => void
  onSelectChat?: (chatId: string) => void
}

export function HistoryDrawer({
  model,
  isOpen,
  onClose,
  onSelectChat,
}: HistoryDrawerProps) {
  const [hoveredId, setHoveredId] = useState<string | null>(null)

  const histories = model ? mockChatHistories[model.id] || [] : []

  if (!isOpen) return null

  return (
    <>
      {/* 背景遮罩 */}
      <div
        className="fixed inset-0 bg-black/10 z-40"
        onClick={onClose}
      />

      {/* 右侧抽屉 - 固定宽度 280px */}
      <div className="fixed top-[60px] right-0 bottom-0 w-[280px] bg-background border-l border-border z-50 shadow-lg animate-in slide-in-from-right-4 flex flex-col">
        {/* 顶部标题栏 */}
        <div className="flex items-center justify-between p-3 border-b border-border flex-shrink-0">
          <div className="flex items-center gap-2">
            <History className="h-4 w-4 text-muted-foreground" />
            <h2 className="font-medium text-sm text-foreground">
              {model?.name || '历史对话'}
            </h2>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="h-7 w-7"
          >
            <X className="h-3.5 w-3.5" />
          </Button>
        </div>

        {/* 内容区 */}
        <ScrollArea className="flex-1 min-h-0">
          <div className="p-2 space-y-1">
            {histories.length > 0 ? (
              histories.map((history) => (
                <div
                  key={history.id}
                  className="group flex items-start justify-between p-2 rounded-md hover:bg-accent transition-colors cursor-pointer"
                  onMouseEnter={() => setHoveredId(history.id)}
                  onMouseLeave={() => setHoveredId(null)}
                  onClick={() => {
                    onSelectChat?.(history.id)
                    onClose()
                  }}
                >
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-foreground truncate">
                      {history.title}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {history.createdAt.toLocaleString('zh-CN', {
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </p>
                  </div>

                  {hoveredId === history.id && (
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-6 w-6 ml-1 flex-shrink-0"
                          onClick={(e) => e.stopPropagation()}
                        >
                          <MoreVertical className="h-3 w-3" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-32">
                        <DropdownMenuItem className="text-xs">重命名</DropdownMenuItem>
                        <DropdownMenuItem className="text-xs text-destructive">
                          删除
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  )}
                </div>
              ))
            ) : (
              <div className="flex items-center justify-center h-24 text-muted-foreground">
                <p className="text-xs">暂无历史对话</p>
              </div>
            )}
          </div>
        </ScrollArea>
      </div>
    </>
  )
}
