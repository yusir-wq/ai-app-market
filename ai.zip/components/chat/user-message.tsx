'use client'

import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Button } from '@/components/ui/button'
import { Copy, Trash2 } from 'lucide-react'
import { useState } from 'react'
import type { ChatMessage } from '@/lib/mock-data'

interface UserMessageProps {
  message: ChatMessage
}

export function UserMessage({ message }: UserMessageProps) {
  const [isHovered, setIsHovered] = useState(false)

  return (
    <div
      className="group flex justify-end mb-4"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="flex items-end gap-2 max-w-md">
        {/* 操作按钮 */}
        {isHovered && (
          <div className="flex gap-1">
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6"
              onClick={() => {
                navigator.clipboard.writeText(message.content)
              }}
            >
              <Copy className="h-3.5 w-3.5" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6"
              onClick={() => console.log('Delete message')}
            >
              <Trash2 className="h-3.5 w-3.5" />
            </Button>
          </div>
        )}

        {/* 消息内容 */}
        <div className="flex flex-col items-end gap-1">
          <div className="bg-primary text-primary-foreground rounded-2xl rounded-tr-sm px-4 py-2 break-words">
            <p className="text-sm">{message.content}</p>
          </div>
          <span className="text-xs text-muted-foreground px-2">
            {message.timestamp.toLocaleTimeString('zh-CN', {
              hour: '2-digit',
              minute: '2-digit',
            })}
          </span>
        </div>

        {/* 用户头像 */}
        <Avatar className="w-6 h-6 flex-shrink-0">
          <AvatarImage src="https://api.dicebear.com/7.x/avataaars/svg?seed=user123" />
          <AvatarFallback>U</AvatarFallback>
        </Avatar>
      </div>
    </div>
  )
}
