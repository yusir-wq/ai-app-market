'use client'

import { useState } from 'react'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { useAuth } from '@/contexts/auth-context'
import { Check } from 'lucide-react'

const PACKAGES = [
  { amount: 8, price: '¥8' },
  { amount: 16, price: '¥16' },
  { amount: 160, price: '¥160' },
  { amount: 400, price: '¥400' },
  { amount: 800, price: '¥800' },
  { amount: 1600, price: '¥1600' },
  { amount: 4000, price: '¥4000' },
]

const PAYMENT_METHODS = [
  { id: 'wechat', name: '微信', icon: '💚' },
  { id: 'alipay', name: '支付宝', icon: '💙' },
]

export function RechargeModal() {
  const { showRechargeModal, setShowRechargeModal, updateBalance } = useAuth()
  const [selectedPackage, setSelectedPackage] = useState<number | null>(null)
  const [selectedPayment, setSelectedPayment] = useState<string | null>('wechat')
  const [isLoading, setIsLoading] = useState(false)
  const [paymentStatus, setPaymentStatus] = useState<'idle' | 'processing' | 'success'>('idle')

  const handleConfirmRecharge = () => {
    if (!selectedPackage) {
      alert('请选择充值额度')
      return
    }

    if (!selectedPayment) {
      alert('请选择支付方式')
      return
    }

    setIsLoading(true)
    setPaymentStatus('processing')

    // 模拟支付处理
    setTimeout(() => {
      updateBalance(selectedPackage)
      setPaymentStatus('success')

      // 2秒后关闭弹窗
      setTimeout(() => {
        setShowRechargeModal(false)
        setSelectedPackage(null)
        setSelectedPayment('wechat')
        setPaymentStatus('idle')
        setIsLoading(false)
      }, 2000)
    }, 2000)
  }

  return (
    <Dialog open={showRechargeModal} onOpenChange={setShowRechargeModal}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>充值额度</DialogTitle>
          <DialogDescription>
            选择充值金额和支付方式
          </DialogDescription>
        </DialogHeader>

        {paymentStatus === 'success' ? (
          <div className="flex flex-col items-center justify-center py-8 space-y-4">
            <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center">
              <Check className="h-8 w-8 text-green-600" />
            </div>
            <h3 className="text-lg font-semibold text-foreground">充值成功！</h3>
            <p className="text-sm text-muted-foreground">
              ¥{selectedPackage} 已添加到您的账户
            </p>
          </div>
        ) : (
          <div className="space-y-6">
            {/* 套餐选择 */}
            <div className="space-y-3">
              <label className="text-sm font-semibold text-foreground">
                选择充值额度
              </label>
              <div className="grid grid-cols-4 gap-2">
                {PACKAGES.map((pkg) => (
                  <button
                    key={pkg.amount}
                    onClick={() => setSelectedPackage(pkg.amount)}
                    disabled={isLoading}
                    className={`p-3 rounded-lg border-2 transition-all ${
                      selectedPackage === pkg.amount
                        ? 'border-primary bg-primary/5'
                        : 'border-border hover:border-primary/50'
                    }`}
                  >
                    <div className="text-center">
                      <div className="font-bold text-foreground">
                        {pkg.amount}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {pkg.price}
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* 支付方式 */}
            <div className="space-y-3">
              <label className="text-sm font-semibold text-foreground">
                支付方式
              </label>
              <div className="grid grid-cols-2 gap-3">
                {PAYMENT_METHODS.map((method) => (
                  <button
                    key={method.id}
                    onClick={() => setSelectedPayment(method.id)}
                    disabled={isLoading}
                    className={`p-4 rounded-lg border-2 transition-all flex items-center gap-2 ${
                      selectedPayment === method.id
                        ? 'border-primary bg-primary/5'
                        : 'border-border hover:border-primary/50'
                    }`}
                  >
                    <span className="text-2xl">{method.icon}</span>
                    <span className="font-medium text-foreground">
                      {method.name}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* 确认按钮 */}
            <div className="space-y-2">
              <Button
                onClick={handleConfirmRecharge}
                disabled={!selectedPackage || !selectedPayment || isLoading}
                className="w-full"
              >
                {paymentStatus === 'processing'
                  ? '处理中... 请稍候'
                  : `确认充值 ¥${selectedPackage || 0}`}
              </Button>
              <p className="text-xs text-center text-muted-foreground">
                确认后将跳转到对应支付页面
              </p>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
