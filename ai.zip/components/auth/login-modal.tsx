'use client'

import { useState, useEffect } from 'react'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { InputOTP, InputOTPGroup, InputOTPSlot } from '@/components/ui/input-otp'
import { useAuth } from '@/contexts/auth-context'
import { QrCode } from 'lucide-react'

export function LoginModal() {
  const { isLoggedIn, showLoginModal, setShowLoginModal, login } = useAuth()
  const [phone, setPhone] = useState('')
  const [code, setCode] = useState('')
  const [codeSent, setCodeSent] = useState(false)
  const [countdown, setCountdown] = useState(0)
  const [isLoading, setIsLoading] = useState(false)

  const handleSendCode = () => {
    if (!phone || phone.length !== 11) {
      alert('请输入有效的11位手机号')
      return
    }

    setIsLoading(true)
    // 模拟发送验证码
    setTimeout(() => {
      setCodeSent(true)
      setCountdown(60)
      setIsLoading(false)
      alert('验证码已发送到您的手机（演示：000000）')
    }, 800)
  }

  const handleLogin = () => {
    if (!code || code.length !== 6) {
      alert('请输入6位验证码')
      return
    }

    setIsLoading(true)
    // 模拟登录
    setTimeout(() => {
      login(phone, code)
      setPhone('')
      setCode('')
      setCodeSent(false)
      setIsLoading(false)
    }, 800)
  }

  // 倒计时逻辑
  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => setCountdown(countdown - 1), 1000)
      return () => clearTimeout(timer)
    }
  }, [countdown])

  return (
    <Dialog open={showLoginModal} onOpenChange={setShowLoginModal}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>登录</DialogTitle>
          <DialogDescription>
            使用手机号和验证码登录，或扫描二维码快速登录
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* 手机号输入 */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">手机号</label>
            <Input
              placeholder="请输入11位手机号"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              disabled={codeSent || isLoading}
              maxLength={11}
              type="tel"
            />
          </div>

          {/* 验证码输入 */}
          {codeSent && (
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">验证码</label>
              <InputOTP maxLength={6} value={code} onChange={setCode} disabled={isLoading}>
                <InputOTPGroup>
                  <InputOTPSlot index={0} />
                  <InputOTPSlot index={1} />
                  <InputOTPSlot index={2} />
                  <InputOTPSlot index={3} />
                  <InputOTPSlot index={4} />
                  <InputOTPSlot index={5} />
                </InputOTPGroup>
              </InputOTP>
              <p className="text-xs text-muted-foreground">
                演示验证码：000000
              </p>
            </div>
          )}

          {/* 获取验证码按钮 */}
          {!codeSent ? (
            <Button
              onClick={handleSendCode}
              disabled={isLoading || !phone}
              className="w-full"
            >
              {isLoading ? '发送中...' : '获取验证码'}
            </Button>
          ) : (
            <Button
              onClick={handleLogin}
              disabled={isLoading || code.length !== 6}
              className="w-full"
            >
              {isLoading ? '登录中...' : '登录'}
            </Button>
          )}

          {/* 倒计时提示 */}
          {codeSent && countdown > 0 && (
            <p className="text-xs text-center text-muted-foreground">
              {countdown}秒后可重新获取验证码
            </p>
          )}

          {/* 二维码登录 */}
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-border"></div>
            </div>
            <div className="relative flex justify-center text-xs uppercase">
              <span className="bg-background px-2 text-muted-foreground">
                或者
              </span>
            </div>
          </div>

          <Button
            variant="outline"
            className="w-full gap-2"
            onClick={() => alert('演示：二维码登录功能')}
          >
            <QrCode className="h-4 w-4" />
            扫描二维码登录
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
