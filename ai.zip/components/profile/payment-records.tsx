'use client'

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'

interface PaymentRecord {
  id: string
  orderNumber: string
  amount: number
  paymentTime: Date
  paymentMethod: string
}

// Mock 支付记录数据
const mockPayments: PaymentRecord[] = [
  {
    id: '1',
    orderNumber: 'ORD-20241218-001',
    amount: 50,
    paymentTime: new Date('2024-12-18 14:00'),
    paymentMethod: '支付宝',
  },
  {
    id: '2',
    orderNumber: 'ORD-20241215-002',
    amount: 100,
    paymentTime: new Date('2024-12-15 10:30'),
    paymentMethod: '微信支付',
  },
  {
    id: '3',
    orderNumber: 'ORD-20241210-003',
    amount: 200,
    paymentTime: new Date('2024-12-10 16:20'),
    paymentMethod: '银行卡',
  },
  {
    id: '4',
    orderNumber: 'ORD-20241208-004',
    amount: 50,
    paymentTime: new Date('2024-12-08 09:15'),
    paymentMethod: '支付宝',
  },
  {
    id: '5',
    orderNumber: 'ORD-20241205-005',
    amount: 100,
    paymentTime: new Date('2024-12-05 13:45'),
    paymentMethod: '微信支付',
  },
  {
    id: '6',
    orderNumber: 'ORD-20241201-006',
    amount: 300,
    paymentTime: new Date('2024-12-01 11:00'),
    paymentMethod: '银行卡',
  },
]

export function PaymentRecords() {
  const totalAmount = mockPayments.reduce((sum, payment) => sum + payment.amount, 0)

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground mb-2">支付记录</h2>
        <div className="flex items-center gap-4">
          <p className="text-muted-foreground">共 {mockPayments.length} 条记录</p>
          <div className="text-sm">
            <span className="text-muted-foreground">总充值: </span>
            <span className="font-semibold text-foreground">¥{totalAmount.toFixed(2)}</span>
          </div>
        </div>
      </div>

      {/* 表格 */}
      <div className="border border-border rounded-lg overflow-hidden">
        <Table>
          <TableHeader className="bg-muted/50">
            <TableRow>
              <TableHead className="w-[180px]">订单号</TableHead>
              <TableHead>充值金额</TableHead>
              <TableHead>支付时间</TableHead>
              <TableHead>支付方式</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {mockPayments.map((payment) => (
              <TableRow key={payment.id} className="hover:bg-muted/50">
                <TableCell className="font-mono text-sm text-foreground">
                  {payment.orderNumber}
                </TableCell>
                <TableCell className="font-medium text-foreground">
                  ¥{payment.amount}
                </TableCell>
                <TableCell className="text-muted-foreground text-sm">
                  {payment.paymentTime.toLocaleString('zh-CN', {
                    year: 'numeric',
                    month: 'short',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </TableCell>
                <TableCell>
                  <Badge variant="outline">{payment.paymentMethod}</Badge>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
