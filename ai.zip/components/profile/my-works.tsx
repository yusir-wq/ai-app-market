'use client'

import { Button } from '@/components/ui/button'
import { Download, Trash2, Filter } from 'lucide-react'
import { useState } from 'react'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'

interface Work {
  id: string
  title: string
  type: 'image' | 'video'
  thumbnail: string
  createdAt: Date
}

// Mock 作品数据
const mockWorks: Work[] = [
  {
    id: '1',
    title: '赛博朋克城市夜景',
    type: 'image',
    thumbnail: '🎨',
    createdAt: new Date('2024-12-18'),
  },
  {
    id: '2',
    title: '科技公司 Logo 设计',
    type: 'image',
    thumbnail: '🎨',
    createdAt: new Date('2024-12-17'),
  },
  {
    id: '3',
    title: '森林插画创作',
    type: 'image',
    thumbnail: '🎨',
    createdAt: new Date('2024-12-16'),
  },
  {
    id: '4',
    title: '产品宣传视频',
    type: 'video',
    thumbnail: '🎬',
    createdAt: new Date('2024-12-15'),
  },
  {
    id: '5',
    title: '教程演示动画',
    type: 'video',
    thumbnail: '🎬',
    createdAt: new Date('2024-12-14'),
  },
  {
    id: '6',
    title: '春节主题海报',
    type: 'image',
    thumbnail: '🎨',
    createdAt: new Date('2024-12-13'),
  },
]

// 按时间分组
function groupByDate(works: Work[]) {
  const groups: Record<string, Work[]> = {}
  works.forEach((work) => {
    const dateStr = work.createdAt.toLocaleDateString('zh-CN')
    if (!groups[dateStr]) {
      groups[dateStr] = []
    }
    groups[dateStr].push(work)
  })
  return groups
}

export function MyWorks() {
  const [typeFilter, setTypeFilter] = useState<'all' | 'image' | 'video'>('all')
  const [sortOrder, setSortOrder] = useState<'newest' | 'oldest'>('newest')

  // 根据过滤条件筛选作品
  const filteredWorks = mockWorks.filter((work) => {
    if (typeFilter === 'all') return true
    return work.type === typeFilter
  })

  // 根据排序条件排序
  const sortedWorks = [...filteredWorks].sort((a, b) => {
    if (sortOrder === 'newest') {
      return b.createdAt.getTime() - a.createdAt.getTime()
    }
    return a.createdAt.getTime() - b.createdAt.getTime()
  })

  const groupedWorks = groupByDate(sortedWorks)

  return (
    <div className="space-y-6">
      {/* 标题 */}
      <div>
        <h2 className="text-2xl font-bold text-foreground mb-2">我的作品</h2>
        <p className="text-muted-foreground">共 {sortedWorks.length} 件作品</p>
      </div>

      {/* 筛选工具栏 */}
      <div className="flex items-center gap-3 flex-wrap">
        <Filter className="h-4 w-4 text-muted-foreground" />
        
        {/* 作品类型筛选 */}
        <Select
          value={typeFilter}
          onValueChange={(value: any) => setTypeFilter(value)}
        >
          <SelectTrigger className="w-[120px]">
            <SelectValue placeholder="全部类型" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">全部</SelectItem>
            <SelectItem value="image">图片</SelectItem>
            <SelectItem value="video">视频</SelectItem>
          </SelectContent>
        </Select>

        {/* 排序方式 */}
        <Select
          value={sortOrder}
          onValueChange={(value: any) => setSortOrder(value)}
        >
          <SelectTrigger className="w-[120px]">
            <SelectValue placeholder="排序" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="newest">最新生成</SelectItem>
            <SelectItem value="oldest">最早生成</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {Object.entries(groupedWorks).length > 0 ? (
        Object.entries(groupedWorks).map(([date, works]) => (
          <div key={date}>
            <h3 className="text-sm font-semibold text-muted-foreground mb-4">
              {date}
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
              {works.map((work) => (
                <div
                  key={work.id}
                  className="group relative overflow-hidden rounded-lg border border-border bg-muted aspect-square flex items-center justify-center"
                >
                  {/* 缩略图 */}
                  <div className="text-5xl">{work.thumbnail}</div>

                  {/* Hover 操作栏 */}
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                    <Button
                      size="sm"
                      variant="secondary"
                      className="gap-2"
                      onClick={() => console.log('Download:', work.id)}
                    >
                      <Download className="h-4 w-4" />
                      下载
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      className="gap-2"
                      onClick={() => console.log('Delete:', work.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                      删除
                    </Button>
                  </div>

                  {/* 标题 */}
                  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-3">
                    <p className="text-sm font-medium text-white truncate">
                      {work.title}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))
      ) : (
        <div className="flex items-center justify-center py-12 text-muted-foreground">
          <p className="text-sm">暂无符合条件的作品</p>
        </div>
      )}
    </div>
  )
}
