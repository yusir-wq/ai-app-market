'use client'

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'

interface ConsumptionRecord {
  id: string
  modelName: string
  modelType: string
  amount: number
  createdAt: Date
  status: 'completed' | 'pending'
}

// Mock 消费记录数据
const mockRecords: ConsumptionRecord[] = [
  {
    id: '1',
    modelName: 'GPT-Image-2',
    modelType: '图片生成',
    amount: 5.5,
    createdAt: new Date('2024-12-18 14:30'),
    status: 'completed',
  },
  {
    id: '2',
    modelName: 'DeepSeek V4 Pro',
    modelType: '聊天模型',
    amount: 2.8,
    createdAt: new Date('2024-12-18 10:15'),
    status: 'completed',
  },
  {
    id: '3',
    modelName: 'Gemini 3 Flash',
    modelType: '视频生成',
    amount: 12.5,
    createdAt: new Date('2024-12-17 16:45'),
    status: 'completed',
  },
  {
    id: '4',
    modelName: 'Qwen-Image-Max',
    modelType: '图片生成',
    amount: 3.2,
    createdAt: new Date('2024-12-17 11:20'),
    status: 'completed',
  },
  {
    id: '5',
    modelName: 'MiniMax-M2.5',
    modelType: '聊天模型',
    amount: 1.5,
    createdAt: new Date('2024-12-16 09:00'),
    status: 'completed',
  },
  {
    id: '6',
    modelName: 'GLM-5-Turbo',
    modelType: '聊天模型',
    amount: 2.0,
    createdAt: new Date('2024-12-15 14:30'),
    status: 'pending',
  },
  {
    id: '7',
    modelName: 'Claude Haiku 4.5',
    modelType: '聊天模型',
    amount: 1.8,
    createdAt: new Date('2024-12-14 10:00'),
    status: 'completed',
  },
  {
    id: '8',
    modelName: 'GPT-Image-2',
    modelType: '图片生成',
    amount: 6.2,
    createdAt: new Date('2024-12-13 15:45'),
    status: 'completed',
  },
]

export function ConsumptionRecords() {
  const totalAmount = mockRecords.reduce((sum, record) => sum + record.amount, 0)

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold text-foreground mb-2">消费记录</h2>
        <div className="flex items-center gap-4">
          <p className="text-muted-foreground">共 {mockRecords.length} 条记录</p>
          <div className="text-sm">
            <span className="text-muted-foreground">总消费: </span>
            <span className="font-semibold text-foreground">¥{totalAmount.toFixed(2)}</span>
          </div>
        </div>
      </div>

      {/* 表格 */}
      <div className="border border-border rounded-lg overflow-hidden">
        <Table>
          <TableHeader className="bg-muted/50">
            <TableRow>
              <TableHead className="w-[200px]">模型名称</TableHead>
              <TableHead>模型类型</TableHead>
              <TableHead className="text-right">消费额度</TableHead>
              <TableHead>时间</TableHead>
              <TableHead>状态</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {mockRecords.map((record) => (
              <TableRow key={record.id} className="hover:bg-muted/50">
                <TableCell className="font-medium text-foreground">
                  {record.modelName}
                </TableCell>
                <TableCell className="text-muted-foreground">
                  {record.modelType}
                </TableCell>
                <TableCell className="text-right font-medium text-foreground">
                  ¥{record.amount.toFixed(2)}
                </TableCell>
                <TableCell className="text-muted-foreground text-sm">
                  {record.createdAt.toLocaleString('zh-CN', {
                    year: 'numeric',
                    month: 'short',
                    day: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                </TableCell>
                <TableCell>
                  <Badge
                    variant={record.status === 'completed' ? 'default' : 'outline'}
                    className={record.status === 'pending' ? 'bg-yellow-50 text-yellow-700' : ''}
                  >
                    {record.status === 'completed' ? '已完成' : '处理中'}
                  </Badge>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
