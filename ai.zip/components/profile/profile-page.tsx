'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { ArrowLeft } from 'lucide-react'
import Link from 'next/link'
import { useSearchParams } from 'next/navigation'
import { MyWorks } from './my-works'
import { ConsumptionRecords } from './consumption-records'
import { PaymentRecords } from './payment-records'

type TabValue = 'works' | 'consumption' | 'payment'

export function ProfilePage() {
  const searchParams = useSearchParams()
  const tabParam = searchParams?.get('tab') as TabValue | null
  const [activeTab, setActiveTab] = useState<TabValue>(tabParam || 'works')

  // 同步 URL 参数到标签状态
  useEffect(() => {
    if (tabParam) {
      setActiveTab(tabParam)
    }
  }, [tabParam])

  return (
    <div className="min-h-screen bg-background">
      {/* 顶部导航 */}
      <div className="h-16 border-b border-border bg-background px-6 flex items-center justify-between sticky top-0 z-40">
        <div className="flex items-center gap-3">
          <Link href="/">
            <Button variant="ghost" size="icon" className="h-8 w-8">
              <ArrowLeft className="h-4 w-4" />
            </Button>
          </Link>
          <h1 className="font-semibold text-lg text-foreground">个人中心</h1>
        </div>

        <div className="flex items-center gap-3">
          <Avatar className="w-8 h-8">
            <AvatarImage src="https://api.dicebear.com/7.x/avataaars/svg?seed=user123" />
            <AvatarFallback>U</AvatarFallback>
          </Avatar>
          <div className="text-sm">
            <p className="font-medium text-foreground">user_12345</p>
            <p className="text-xs text-muted-foreground">已认证用户</p>
          </div>
        </div>
      </div>

      {/* 主体内容 */}
      <div className="flex h-[calc(100vh-64px)]">
        {/* 左侧 Tabs 导航 */}
        <div className="w-64 border-r border-border bg-muted/30 p-6">
          <Tabs
            value={activeTab}
            onValueChange={(v) => setActiveTab(v as TabValue)}
            orientation="vertical"
            className="w-full"
          >
            <TabsList className="flex flex-col w-full h-auto gap-2 bg-transparent p-0">
              <TabsTrigger
                value="works"
                className="w-full justify-start px-4 py-2 rounded-lg text-left data-[state=active]:bg-accent"
              >
                我的作品
              </TabsTrigger>
              <TabsTrigger
                value="consumption"
                className="w-full justify-start px-4 py-2 rounded-lg text-left data-[state=active]:bg-accent"
              >
                消费记录
              </TabsTrigger>
              <TabsTrigger
                value="payment"
                className="w-full justify-start px-4 py-2 rounded-lg text-left data-[state=active]:bg-accent"
              >
                支付记录
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>

        {/* 右侧内容区 */}
        <div className="flex-1 overflow-auto">
          <div className="p-8">
            {activeTab === 'works' && <MyWorks />}
            {activeTab === 'consumption' && <ConsumptionRecords />}
            {activeTab === 'payment' && <PaymentRecords />}
          </div>
        </div>
      </div>
    </div>
  )
}
